#include "Field.h"
#include <iostream>

Field::Field(sf::Vector2f window) {
    std::srand(std::time(0));
    *mSize = window;
    *mSizePosition = sf::Vector2f((*mSize).x / static_cast<float>(*mSquareOfSideCount), (*mSize).y / static_cast<float>(*mSquareOfSideCount));
    (*mBackgroundTexture).loadFromFile("..\\square0.png");
    (*mBackgroundTexture).setRepeated(true);
    (*mBackgroundTexture).setSmooth(true);
    (*mWinTexture).loadFromFile("..\\win.png");
    (*mWinTexture).setSmooth(true);
    (*mBackground).setSize(*mSize);
    (*mWIN).setSize(*mSize);
    (*mWIN).setTexture(mWinTexture);
    (*mSquareTime).restart();
    for (int i = 0; i < *mSquareOfSideCount; ++i) {
        mSquares[i] = new Square[*mSquareOfSideCount];
        mIsEmpty[i] = new bool;
    }
}

    void Field::init() {
        for (int i = 0; i < *mSquareOfSideCount; ++i) {
            for (int j = 0; j < *mSquareOfSideCount; ++j) {
                mIsEmpty[i][j] = true;
            }
        }
        (*mBackground).setTexture(mBackgroundTexture);
        (*mBackground).setTextureRect(sf::IntRect(0, 0, (*mSize).x, (*mSize).y));

        do {
            (*mSquareTime).restart();
            *mPositionX = std::rand() % *mSquareOfSideCount;
            *mPositionY = std::rand() % *mSquareOfSideCount;
        } while(!mIsEmpty[*mPositionY][*mPositionX]);
        Square* newSquare1 = new Square(*mSizePosition);
        (*newSquare1).updatePosition(sf::Vector2f(static_cast<float >(*mPositionX) * (*mSizePosition).x,
                                                 static_cast<float>(*mPositionY) * (*mSizePosition).y));
        mSquares[*mPositionY][*mPositionX] = *newSquare1;
        mIsEmpty[*mPositionY][*mPositionX] = false;

        do {
            (*mSquareTime).restart();
            *mPositionX = std::rand() % *mSquareOfSideCount;
            *mPositionY = std::rand() % *mSquareOfSideCount;
        } while(!mIsEmpty[*mPositionY][*mPositionX]);
        Square* newSquare2 = new Square(*mSizePosition);
        (*newSquare2).updatePosition(sf::Vector2f(static_cast<float >(*mPositionX) * (*mSizePosition).x,
                                                 static_cast<float>(*mPositionY) * (*mSizePosition).y));
        mSquares[*mPositionY][*mPositionX] = *newSquare2;
        mIsEmpty[*mPositionY][*mPositionX] = false;
    }

//    Square** Field::getSquares() {
//        return mSquares;
//    }

void Field::addSquare(Square* newSquare) {
    //Square newSquare(mSizePosition);
    do {
        (*mSquareTime).restart();
        *mPositionX = std::rand() % *mSquareOfSideCount;
        *mPositionY = std::rand() % *mSquareOfSideCount;
    } while(!mIsEmpty[*mPositionY][*mPositionX]);
    (*newSquare).updatePosition(sf::Vector2f(static_cast<float >(*mPositionX) * (*mSizePosition).x,
                                             static_cast<float>(*mPositionY) * (*mSizePosition).y));
    mSquares[*mPositionY][*mPositionX] = *newSquare;
    mIsEmpty[*mPositionY][*mPositionX] = false;
}

sf::Vector2f Field::getSizeSquare() {
    return *mSizePosition;
}

void Field::draw(sf::RenderTarget& target, sf::RenderStates states) const {
    target.draw(*mBackground);
    for(int i = 0; i < *mSquareOfSideCount; ++i) {
        for(int j = 0; j < *mSquareOfSideCount; ++j) {
            if (!mIsEmpty[i][j]) {
                target.draw(mSquares[i][j]);
            }
        }
    }
    if(*mIsWin) {
        target.draw(*mWIN);
    }
}

void Field::moveDown() {
    for (int j = 0; j < *mSquareOfSideCount; ++j) {
        *mSquaresCountBefore = 0;
        for (int i = *mSquareOfSideCount - 1; i >= 0; --i) {
            if(!mIsEmpty[i][j]) {
                mIsEmpty[i][j] = true;
                if (*mSquaresCountBefore == 0 || mSquares[*mSquareOfSideCount - *mSquaresCountBefore][j].getLevel() != mSquares[i][j].getLevel()) {
                    mIsEmpty[*mSquareOfSideCount - 1 - *mSquaresCountBefore][j] = false;
                    mSquares[*mSquareOfSideCount - 1 - *mSquaresCountBefore][j] = mSquares[i][j];
                    mSquares[*mSquareOfSideCount - 1 - *mSquaresCountBefore][j].updatePosition(
                            sf::Vector2f(mSquares[*mSquareOfSideCount - 1 - *mSquaresCountBefore][j].getPosition().x,
                                         (float) (*mSquareOfSideCount - 1 - *mSquaresCountBefore) *
                                         (*mSizePosition).y));
                    ++(*mSquaresCountBefore);
                }
                else {
                    mSquares[*mSquareOfSideCount - *mSquaresCountBefore][j].levelUp();
                }
            }
        }
    }
    do {
        (*mSquareTime).restart();
        *mPositionX = std::rand() % *mSquareOfSideCount;
        *mPositionY = std::rand() % *mSquareOfSideCount;
    } while(!mIsEmpty[*mPositionY][*mPositionX]);
    Square* newSquare = new Square(*mSizePosition);
    (*newSquare).updatePosition(sf::Vector2f(static_cast<float >(*mPositionX) * (*mSizePosition).x,
                                             static_cast<float>(*mPositionY) * (*mSizePosition).y));
    mSquares[*mPositionY][*mPositionX] = *newSquare;
    mIsEmpty[*mPositionY][*mPositionX] = false;
}

void Field::moveUp() {
    for (int j = 0; j < *mSquareOfSideCount; ++j) {
        *mSquaresCountBefore = 0;
        for (int i = 0; i < *mSquareOfSideCount; ++i) {
            if(!mIsEmpty[i][j]) {
                mIsEmpty[i][j] = true;
                if (*mSquaresCountBefore == 0 || mSquares[*mSquaresCountBefore - 1][j].getLevel() != mSquares[i][j].getLevel()) {
                    mIsEmpty[*mSquaresCountBefore][j] = false;
                    mSquares[*mSquaresCountBefore][j] = mSquares[i][j];
                    mSquares[*mSquaresCountBefore][j].updatePosition(
                            sf::Vector2f(mSquares[*mSquaresCountBefore][j].getPosition().x,
                                         (float) (*mSquaresCountBefore) * (*mSizePosition).y));
                    ++(*mSquaresCountBefore);
                }
                else {
                    mSquares[*mSquaresCountBefore - 1][j].levelUp();
                }
            }
        }
    }
    do {
        (*mSquareTime).restart();
        *mPositionX = std::rand() % *mSquareOfSideCount;
        *mPositionY = std::rand() % *mSquareOfSideCount;
    } while(!mIsEmpty[*mPositionY][*mPositionX]);
    Square* newSquare = new Square(*mSizePosition);
    (*newSquare).updatePosition(sf::Vector2f(static_cast<float >(*mPositionX) * (*mSizePosition).x,
                                             static_cast<float>(*mPositionY) * (*mSizePosition).y));
    mSquares[*mPositionY][*mPositionX] = *newSquare;
    mIsEmpty[*mPositionY][*mPositionX] = false;
}

void Field::moveLeft() {
    for (int i = 0; i < *mSquareOfSideCount; ++i) {
        *mSquaresCountBefore = 0;
        for (int j = 0; j < *mSquareOfSideCount; ++j) {
            if(!mIsEmpty[i][j]) {
                mIsEmpty[i][j] = true;
                if (*mSquaresCountBefore == 0 || mSquares[i][*mSquaresCountBefore - 1].getLevel() != mSquares[i][j].getLevel()) {
                    mIsEmpty[i][*mSquaresCountBefore] = false;
                    mSquares[i][*mSquaresCountBefore] = mSquares[i][j];
                    mSquares[i][*mSquaresCountBefore].updatePosition(
                            sf::Vector2f((float) (*mSquaresCountBefore) * (*mSizePosition).x,
                                         mSquares[i][*mSquaresCountBefore].getPosition().y));
                    ++(*mSquaresCountBefore);
                }
                else {
                    mSquares[i][*mSquaresCountBefore - 1].levelUp();
                }
            }
        }
    }
    do {
        (*mSquareTime).restart();
        *mPositionX = std::rand() % *mSquareOfSideCount;
        *mPositionY = std::rand() % *mSquareOfSideCount;
    } while(!mIsEmpty[*mPositionY][*mPositionX]);
    Square* newSquare = new Square(*mSizePosition);
    (*newSquare).updatePosition(sf::Vector2f(static_cast<float >(*mPositionX) * (*mSizePosition).x,
                                             static_cast<float>(*mPositionY) * (*mSizePosition).y));
    mSquares[*mPositionY][*mPositionX] = *newSquare;
    mIsEmpty[*mPositionY][*mPositionX] = false;
}


void Field::moveRight() {
    for (int i = 0; i < *mSquareOfSideCount; ++i) {
        *mSquaresCountBefore = 0;
        for (int j = *mSquareOfSideCount - 1; j >= 0; --j) {
            if(!mIsEmpty[i][j]) {
                mIsEmpty[i][j] = true;
                if (*mSquaresCountBefore == 0 || mSquares[i][*mSquareOfSideCount - *mSquaresCountBefore].getLevel() != mSquares[i][j].getLevel()) {
                    mIsEmpty[i][*mSquareOfSideCount - 1 - *mSquaresCountBefore] = false;
                    mSquares[i][*mSquareOfSideCount - 1 - *mSquaresCountBefore] = mSquares[i][j];
                    mSquares[i][*mSquareOfSideCount - 1 - *mSquaresCountBefore].updatePosition(
                            sf::Vector2f((float) (*mSquareOfSideCount - 1 - *mSquaresCountBefore) * (*mSizePosition).x,
                                         mSquares[i][*mSquareOfSideCount - 1 - *mSquaresCountBefore].getPosition().y));
                    ++(*mSquaresCountBefore);
                }
                else {
                    mSquares[i][*mSquareOfSideCount - *mSquaresCountBefore].levelUp();
                }
            }
        }
    }
    do {
        (*mSquareTime).restart();
        *mPositionX = std::rand() % *mSquareOfSideCount;
        *mPositionY = std::rand() % *mSquareOfSideCount;
    } while(!mIsEmpty[*mPositionY][*mPositionX]);
    Square* newSquare = new Square(*mSizePosition);
    (*newSquare).updatePosition(sf::Vector2f(static_cast<float >(*mPositionX) * (*mSizePosition).x,
                                             static_cast<float>(*mPositionY) * (*mSizePosition).y));
    mSquares[*mPositionY][*mPositionX] = *newSquare;
    mIsEmpty[*mPositionY][*mPositionX] = false;
}

Field::~Field() {
    for(int i = 0; i < *mSquareOfSideCount; ++i) {
        delete mSquares[i];
        delete mIsEmpty[i];
    }
    delete[] mSquares;
    delete[] mIsEmpty;
    delete mSquaresCountBefore;
    delete mSizePosition;
    delete mSize;
    delete mPositionX;
    delete mBackground;
    delete mBackgroundTexture;
    delete mSquareTime;
    delete mPositionY;
    delete mSquareOfSideCount;
    delete mIsWin;
    delete mWinTexture;
    delete mWIN;
    delete mIsLose;
}

void Field::isWin() {
    for (int i = 0; i < *mSquareOfSideCount; ++i) {
        for (int j = 0; j < *mSquareOfSideCount; ++j) {
            if (!mIsEmpty[i][j] and mSquares[i][j].getLevel() == 11) {
                *mIsWin = true;
            }
        }
    }
}


